select FIRST_NAME "First Name", LAST_NAME "Last Name"
from employees;