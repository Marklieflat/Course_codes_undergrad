select FIRST_NAME
from employees
where FIRST_NAME like '_a%';