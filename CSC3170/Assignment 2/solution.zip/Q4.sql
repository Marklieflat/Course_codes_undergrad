select MAX(SALARY), MIN(SALARY)
from employees;