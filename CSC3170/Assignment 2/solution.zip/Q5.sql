select EMPLOYEE_ID, round(SALARY/12, 2)
from employees;