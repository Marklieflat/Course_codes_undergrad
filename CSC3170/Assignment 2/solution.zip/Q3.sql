select EMPLOYEE_ID, SALARY
from employees 
order by SALARY;