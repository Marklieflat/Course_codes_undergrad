All files should be named by entity (role) names (lower-cased, spaces replaced by underscores if any).
	For example, the entity product should be named `product.csv`, with columns `INVENTORY`, `PRODUCT_NAME`, `PRICE` and `CATEGORY`.

Checklist:

Jialin:
	complaint.csv (10,000), user.csv (10,000)
Kexuan:
	brand.csv (324), order.csv (20,003)
Guiming:
	product.csv (9,001), review.csv (20,003), skin.csv (3)， applicability.csv (9,001)