B*.csv: output of basicBasic queries from basic_queries.sql.

A*.csv: output of Analytical queries from analytical_queries.sql.