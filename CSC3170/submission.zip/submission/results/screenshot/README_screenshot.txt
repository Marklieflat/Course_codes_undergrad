B*.png: screenshots of codes and outputs from basic_queries.sql.

A*.png: screenshots of codes and outputs from analytical_queries.sql.