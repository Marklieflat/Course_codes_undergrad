load_data.sql: load data from csv files.


create_table.sql: create table in MYSQL.


basic_queries.sql: MYSQL queries for practical daily oprerations and activities (including insertion, deletion, updating, simple retrieval).


analytical_queries.sql: sample MYSQL queries of an analytic or data mining nature.