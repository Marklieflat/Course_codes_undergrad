-- -----------------------------------------------------
-- ---------------- Solution for Q2 --------------------
-- -----------------------------------------------------
select FIRST_NAME as 'First Name', LAST_NAME as 'Last Name'
from employees