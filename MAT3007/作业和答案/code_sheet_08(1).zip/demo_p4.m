
% test function
f.obj       = @(x) 100*(x(2)-x(1)^2)^2 + 1*(1-x(1))^2;
f.grad      = @(x) [400*(x(1)^2-x(2))*x(1)+2*(x(1)-1);200*(x(2)-x(1)^2)];
f.hess      = @(x) [400*(3*x(1)^2-x(2))+2,-400*x(1);-400*x(1),200];
f.obj_print = @(x,y) 100*(y-x.^2).^2 + 1*(1-x).^2;

% initial point
x0_ref      = [-1;-0.5];

% options
opts.maxit  = 25000;
opts.trace  = true;
opts.print  = true;
opts.mode   = 'armijo-linesearch';

opts.s      = 1;
opts.sigma  = 0.5;
opts.gamma  = 1e-4;

nr_ini      = 1;

xl = -1.5; xr = 1.5; yl = -1; yr = 2;

[X,Y]       = meshgrid(xl:0.01:xr,yl:0.01:yr);
Z           = f.obj_print(X,Y);
max_z       = max(max(Z));

tol         = 1e-7;

figure;
hold on

ch          = contour(X,Y,Z,logspace(-2.5,4,30));

fprintf(1,'ITER ; OBJ.VAL ; G.NORM ; [X1/X2]\n');

for i = 1:nr_ini
     x0          = x0_ref(:,i);
     
     [x,out]     = gradient_method(f,x0,tol,opts);
     
     fprintf(1,'[%5i] ; %1.6e ; %1.6e ; [%1.6e/%1.6e]\n',out.iter,f.obj(x),norm(f.grad(x)),x(1),x(2));
    
     plot3(x0(1),x0(2),max_z,'.','Color',[152,24,147]/255,'MarkerSize',12);
     plot3(out.trace.x(:,1),out.trace.x(:,2),max_z*ones(size(out.trace.x,1),1),'-','Color',[152,24,147]/255,'LineWidth',1.1,'MarkerSize',10);

     [x,out]  = newton_glob(f,x0,tol,opts);
     
     fprintf(1,'[%5i] ; %1.6e ; %1.6e ; [%1.6e/%1.6e]\n',out.iter,f.obj(x),norm(f.grad(x)),x(1),x(2));
     
     plot3(x0(1),x0(2),max_z,'.','Color',[17,140,17]/255,'MarkerSize',12);
     plot3(out.trace.x(:,1),out.trace.x(:,2),max_z*ones(size(out.trace.x,1),1),'-','Color',[17,140,17]/255,'LineWidth',1.1,'MarkerSize',10);
end

plot3(1,1,1.1*max_z,'s','MarkerSize',10,'MarkerFaceColor',[219,160,1]/255,'MarkerEdgeColor',[17,140,17]/255);

hold off
colormap(flipud(copper))    

axis([xl xr yl yr])

set(gcf,'Renderer', 'painters');
saveas(gcf,'plot_p4-ros','epsc');
