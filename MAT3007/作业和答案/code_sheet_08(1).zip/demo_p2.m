
% test function
f.obj       = @(x) x(1)^4+(2/3)*x(1)^3+0.5*x(1)^2-2*x(1)^2*x(2)+(4/3)*x(2)^2;
f.grad      = @(x) [4*x(1)^3+2*x(1)^2+x(1)-4*x(1)*x(2);-2*x(1)^2+(8/3)*x(2)];
f.hess      = @(x) [12*x(1)^2+4*x(1)+1-4*x(2),-4*x(1);-4*x(1),8/3];
f.obj_print = @(x,y) x.^4+(2/3)*x.^3+0.5*x.^2-2*x.^2.*y+(4/3)*y.^2;

% initial point
%x0_ref      = [-3,-1.5,0,1.5,3,-3,-1.5,0,1.5,3,-3,-3,-3,3,3,3;-3*ones(1,5),3*ones(1,5),-1.5,0,1.5,-1.5,0,1.5];
x0_ref      = [-3,3,-3,3;3,3,-3,-3];

% options
opts.maxit  = 10000;
opts.trace  = true;
opts.print  = false;
opts.mode   = 'armijo-linesearch';

%opts.mode   = 'exact-linesearch';

opts.s      = 1;
opts.sigma  = 0.5;
opts.gamma  = 0.1; 

nr_ini      = 4; %16;

xl = -3.5; xr = 3.5; yl = -3.5; yr = 3.5;

[X,Y]       = meshgrid(xl:0.01:xr,yl:0.01:yr);
Z           = f.obj_print(X,Y);
max_z       = max(max(Z));

figure;
hold on

contour(X,Y,Z,logspace(-2,3,40))

fprintf(1,'- - - gradient method; step size: %s; n = %g; \n',opts.mode,2);
fprintf(1,'ITER ; OBJ.VAL ; G.NORM ; [X1/X2]\n');

for i = 1:nr_ini
     x0          = x0_ref(:,i);

     [x,out]     = gradient_method(f,x0,1e-5,opts);
     %[x,out]    = adagrad(f,x0,1e-5,opts);
     %[x,out]    = newton_glob(f,x0,1e-8,opts);
          
     if norm(x-[0;0]) <= 0.1
         clr = [152,24,147]/255;
     elseif norm(x-[-1;3/4]) <= 0.1
         clr = [0,101,188]/255;
     else
         clr = [1,1,1];
     end
         
     fprintf(1,'[%5i] ; %1.6e ; %1.6e ; [%1.6e/%1.6e]\n',out.iter,f.obj(x),norm(f.grad(x)),x(1),x(2));

     plot3(x0(1),x0(2),max_z,'.','Color',clr,'MarkerSize',13);
     plot3(out.trace.x(:,1),out.trace.x(:,2),max_z*ones(size(out.trace.x,1),1),'-','Color',clr,'LineWidth',1.5,'MarkerSize',10);

end

plot3(0,0,1.1*max_z,'s','MarkerSize',10,'MarkerFaceColor',[219,160,1]/255,'MarkerEdgeColor',[152,24,147]/255);
plot3(-1,3/4,1.1*max_z,'o','MarkerSize',8,'MarkerFaceColor',[219,160,1]/255,'MarkerEdgeColor',[0,101,188]/255);

hold off
colormap(flipud(copper))    

axis([xl xr yl yr])

set(gcf,'Renderer', 'painters');
saveas(gcf,'plot_p2-01','epsc');