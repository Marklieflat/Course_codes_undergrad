function [x,out] = gradient_method(f,x0,tol,opts)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic; 

if ~isfield(opts,'maxit')
    opts.maxit  = 10000;
end

if ~isfield(opts,'mode')
    opts.mode       = 'fixed-step-size';
    opts.alpha      = 1;
elseif strcmp(opts.mode,'fixed-step-size') 
    if ~isfield(opts,'alpha')
        opts.alpha  = 1; 
    elseif ~isscalar(opts.alpha) || ~isreal(opts.alpha) || opts.alpha <= 0 || opts.alpha > Inf
        error('step size alpha must be in (0,Inf)!');
    end
elseif strcmp(opts.mode,'armijo-linesearch')
    if ~isfield(opts,'gamma')
        opts.gamma  = 0.1; 
    elseif ~isscalar(opts.gamma) || ~isreal(opts.gamma) || opts.gamma <= 0 || opts.gamma >= 1
        error('parameter gamma must be in (0,1)!');
    end
    if ~isfield(opts,'s')
        opts.s  = 1; 
    elseif ~isscalar(opts.s) || ~isreal(opts.s) || opts.s <= 0 || opts.s > Inf
        error('parameter s must be in (0,Inf)!');
    end
elseif strcmp(opts.mode,'exact-linesearch')
    if ~isfield(opts,'opts_au')
        opts_au.display = false;
        opts_au.maxit   = 100;
        opts_au.tol     = 1e-6;
        opts_au.s       = 2;
    end
end

x           = x0;

if strcmp(opts.mode,'fixed-step-size')
    alpha   = opts.alpha;
else
    alpha   = 0;
end

% prepare trace in output
if opts.trace
    [trace.res, trace.time]  = deal(zeros(opts.maxit,1));
    if length(x) == 2
        trace.x              = zeros(opts.maxit,2);
    end
end

if opts.print
    fprintf(1,'- - - gradient method with %s; n = %g\n',opts.mode,length(x));
    fprintf(1,'ITER ; OBJ.VAL ; G.NORM ; STEP.SIZE\n');
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAIN LOOP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for iter = 1:opts.maxit
    
    %----------------------------------------------------------------------
    % calculate gradient
    %----------------------------------------------------------------------
    g   = f.grad(x);
    ng  = norm(g);
    
    if opts.print
        obj_val   = f.obj(x);
        fprintf(1,'[%5i] ; %1.6f ; %1.4e ; %1.2f\n',iter,obj_val,ng,alpha);
    end
    
    % save information for graphic output
    if opts.trace  
        trace.res(iter)     = ng;
        trace.time(iter)    = toc;
        if length(x) == 2
            trace.x(iter,:) = x';
        end
    end
    
    %----------------------------------------------------------------------
    % stopping criterion
    %----------------------------------------------------------------------
    
    if ng <= tol
        break
    end
    
    %----------------------------------------------------------------------
    % step size and main update
    %----------------------------------------------------------------------
    
    switch opts.mode 
        case 'fixed-step-size'
            x           = x - opts.alpha*g; 
        case 'armijo-linesearch'
            if iter == 1
                f_old   = f.obj(x);
            end
            alpha       = opts.s;
            x_old       = x;
            x           = x_old - alpha*g;
            f_new       = f.obj(x);
            a_counter   = 1;
            
            while f_new - f_old > - alpha*opts.gamma*ng^2 && a_counter <= 100
                alpha       = alpha/2;
                x           = x_old - alpha*g;
                f_new       = f.obj(x);
                a_counter   = a_counter + 1;
            end
            
            f_old       = f_new;
        case 'exact-linesearch'
            x_old       = x;
            phi         = @(alpha) f.obj(x_old - alpha*g);
            
            alpha       = ausection(phi,0,opts_au.s,opts_au);
    
            x           = x_old - alpha*g;
        case 'diminishing'
            alp     = opts.alpha(iter);
            x       = x - alp*g;
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GENERATE OUTPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

out.time            = toc;
out.iter            = iter;

if opts.trace
    trace.res       = trace.res(1:iter);
    trace.time      = trace.time(1:iter);
    if length(x) == 2
        trace.x     = trace.x(1:iter,:);
    end
    out.trace       = trace;
end

end

