function [x,out] = newton_glob(f,x0,tol,opts)

% === INPUT ==========
% f      a structure for the objective function
%   .obj(x)    returns the function value at x
%   .grad(x)   returns the gradient of f at x
%   .hess(x)   returns the hessian of f at x
% x0     initial point
% tol    tolerance parameter
% opts   a structure with options
% === OUTPUT =========
% x      a potential stationary point of min_x f(x)

tic; 

x      = x0;
f_old  = f.obj(x);
type   = 'N';
alpha  = -1;

if opts.print
    fprintf(1,'- - - globalized newton method; n = %g\n',length(x));
    fprintf(1,'ITER ; OBJ.VAL ; G.NORM ; ALPHA ; TYPE \n');
end

% prepare trace in output
if opts.trace
    [trace.res, trace.time]  = deal(zeros(opts.maxit,1));
    if length(x) == 2
        trace.x              = zeros(opts.maxit,2);
    end
end

% main loop
for  iter = 1:opts.maxit
    x_old   = x;
    g       = f.grad(x);
    ng      = norm(g);

    if opts.print
        fprintf(1,'[%4i] ; %2.6f ; %1.4e ; %1.3f ; %s\n',iter,f_old,ng,alpha,type);
    end
    
    % save information for graphic output
    if opts.trace  
        trace.res(iter)     = ng;
        trace.time(iter)    = toc;
        if length(x) == 2
            trace.x(iter,:) = x';
        end
    end
    
    if ng <= tol
       break;
    end

    d       = - f.hess(x)\g;
    
    gtd     = d'*g;
    nd      = norm(d);
      
    if - gtd < 1e-6*min(1,nd^0.1)*nd^2
        d       = -g;
        gtd     = -ng^2;
        type    = 'G';
    else
        type    = 'N';
    end
    
    alpha   = 1;
    x       = x_old + alpha*d;
    f_new   = f.obj(x);
    acount  = 1;

    while f_new - f_old > alpha*opts.gamma*gtd && acount <= 100
        alpha   = alpha/2;
        x       = x_old + alpha*d;
        f_new   = f.obj(x);
        acount  = acount + 1;
    end
    
    f_old   = f_new;
end

out.time            = toc;
out.iter            = iter;

if opts.trace
    trace.res       = trace.res(1:iter);
    trace.time      = trace.time(1:iter);
    if length(x) == 2
        trace.x     = trace.x(1:iter,:);
    end
    out.trace       = trace;
end

