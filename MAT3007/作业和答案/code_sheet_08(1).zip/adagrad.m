function [x,out] = adagrad(f,x0,tol,opts)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic; 

if ~isfield(opts,'maxit')
    maxit       = 1000;
else
    maxit       = opts.maxit;
end

if ~isfield(opts,'mode')
    opts.mode       = 'fixed-step-size';
    opts.alpha      = 1;
elseif strcmp(opts.mode,'fixed-step-size') 
    if ~isfield(opts,'alpha')
        opts.alpha  = 1; 
    elseif ~isscalar(opts.alpha) || ~isreal(opts.alpha) || opts.alpha <= 0 || opts.alpha > Inf
        error('step size sigma must be in (0,Inf)!');
    end
elseif strcmp(opts.mode,'armijo-linesearch')
    gamma           = opts.gamma;
end

x   = x0;

% prepare trace in output
if opts.trace
    [trace.res, trace.time]  = deal(zeros(maxit,1));
    if length(x) == 2
        trace.x              = zeros(maxit,2);
    end
end

save_g  = zeros(length(x),opts.m); 
sum_g   = zeros(length(x),1);
counter = 1;

if opts.print
   fprintf(1,'- - - adagrad; step size: %s; n = %g; \n',opts.mode,length(x));
   fprintf(1,'ITER ; OBJ.VAL ; G.NORM ; STEP.SIZE ; COU \n');
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAIN LOOP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for iter = 1:opts.maxit
    
    %----------------------------------------------------------------------
    % calculate gradient
    %----------------------------------------------------------------------
    g   = f.grad(x);
    ng  = norm(g);
    
    if iter <= opts.m
        save_g(:,counter)   = g; 
        sum_g               = sum_g + g.^2; 
        counter             = mod(counter,opts.m)+1; 
    else
        sum_g               = sum_g - save_g(:,counter).^2 + g.^2; 
        save_g(:,counter)   = g; 
        counter             = mod(counter,opts.m)+1;
    end
    
    d  = g./sqrt(opts.eps + sum_g); 
    
    % save information for graphic output
    if opts.trace  
        trace.res(iter)     = norm(g);
        trace.time(iter)    = toc;
        if length(x) == 2
            trace.x(iter,:) = x';
        end
    end
    
    if opts.print
        if iter == 1
            fprintf(1,'[%4i] ; %1.6f ; %1.4e ; %1.2e ; %g \n',iter,f.obj(x),ng,0,counter);
        else
            fprintf(1,'[%4i] ; %1.6f ; %1.4e ; %1.2e ; %g \n',iter,f.obj(x),ng,alp,counter);
        end
    end
    
    %----------------------------------------------------------------------
    % stopping criterion
    %----------------------------------------------------------------------
    if ng <= tol
        break
    end
    
    %----------------------------------------------------------------------
    % calculate new iterate
    %----------------------------------------------------------------------
    switch opts.mode 
        case 'fixed-step-size'
            alp     = opts.alpha; 
            x       = x - alp*d; 
        case 'armijo-linesearch'
            if iter == 1
                f_old   = f.obj(x);
            end
            alp         = opts.s;
            x_old       = x;
            x           = x_old - alp*d;
            f_new       = f.obj(x);
            gtd         = g'*d;
            a_counter   = 1;
            
            while f_new - f_old > - alp*gamma*gtd && a_counter <= 100
                alp         = opts.sigma*alp;
                x           = x_old - alp*d;
                f_new       = f.obj(x);
                a_counter   = a_counter + 1;
            end
            
            f_old       = f_new;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GENERATE OUTPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

out.time            = toc;
out.iter            = iter;

if opts.trace
    trace.res       = trace.res(1:iter);
    trace.time      = trace.time(1:iter);
    if length(x) == 2
        trace.x     = trace.x(1:iter,:);
    end
    out.trace       = trace;
end

end

