% demo_p1

% options
options.maxit   = 100;
options.tol     = 1e-5;
options.display = true;

% function
f               = @(x) -(log(x)-2*(x-1)/(x+1))/(x-1)^2;
g               = @(x) 2*(log(x)-2*(x-1)/(x+1))/(x-1)^3-(1/x-4/(x+1)^2)/(x-1)^2;

xl              = 1.5;
xr              = 4.5;

[xb,gx]         = bisection(g,xl,xr,options);
[xa]            = ausection(f,xl,xr,options);