% Objective function
function y = obj(x)
y = x(1)^4 + 2/3 * x(1)^3 + 0.5 * x(1)^2 - 2 * x(1)^2 * x(2) + 4/3 * x(2)^2


