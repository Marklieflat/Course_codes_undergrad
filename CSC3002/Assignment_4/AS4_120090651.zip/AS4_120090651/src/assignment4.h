#ifndef ASSIGNMENT4_H
#define ASSIGNMENT4_H

#include "HFractal.h"
#include "KnightsTour.h"
#include "MergeSort.h"
#include "SimpleTextEditor.h"

int test1() ;
int test2() ;
int test3() ;
int test4() ;

#endif // ASSIGNMENT4_H
