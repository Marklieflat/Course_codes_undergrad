// This header file doesn't do much, but it's good to demonstrate that it's
// possible to create and edit header files

#include "filelib.h"
#include "simpio.h"
#include "strlib.h"
using namespace std;

/* Function prototypes */

void banishLetters();
