#include <iostream>
#include <string>
#include "intarray.h"
#include "strlib.h"
using namespace std;

/* Function prototypes */

int P1_test();
int P2a_test();
int P2b_test();
int P2c_test();
