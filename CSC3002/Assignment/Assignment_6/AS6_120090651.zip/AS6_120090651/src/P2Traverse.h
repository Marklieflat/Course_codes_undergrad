#include <iostream>
#include <fstream>
#include <string>
#include "set.h"
#include "simplegraph.h"
#include "stack.h"
#include "queue.h"
#include "foreach.h"

/* Function prototypes */


/* Main program */
void dfs(Node *start);
void bfs(Node *start);
